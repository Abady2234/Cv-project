# CVForge — Full Stack

This version implements a real end-to-end path:

**LinkedIn PDF → text extraction → OpenAI structured CV → editable CV → real PDF**

## Run

1. Copy `.env.example` to `.env`
2. Add `OPENAI_API_KEY`
3. Run:

```bash
npm install
npm run dev
```

Open `http://localhost:5173`.

## LinkedIn URL

The URL input validates LinkedIn URLs, but direct profile scraping is deliberately not implemented. LinkedIn's current API requires OAuth/authorized access for member data, and richer profile fields are restricted.

For a production product, use one of these:

### A. LinkedIn OAuth
Add a LinkedIn app and configure:
- LINKEDIN_CLIENT_ID
- LINKEDIN_CLIENT_SECRET
- LINKEDIN_REDIRECT_URI

Then implement the OAuth authorization-code callback and request only permissions your LinkedIn app is approved for.

### B. LinkedIn PDF export
The included `/api/generate/from-pdf` endpoint is already functional. A user can export their own LinkedIn profile as PDF and upload it. This is the recommended immediate MVP because it gives the AI the user's actual work history, education, skills, etc.

## AI

The backend uses OpenAI Responses API with strict JSON schema output. Keep the API key server-side.

## PDF

The backend creates a real selectable-text A4 PDF using PDFKit.

## Production hardening

Before launch add:
- Authentication + database
- Persistent CV storage
- Rate limiting
- Malware/file validation
- Object storage for uploads if files need persistence
- Delete-after-processing policy for uploaded PDFs
- Stripe billing
- LinkedIn OAuth after approval
- HTTPS and secure cookies
- Logging/monitoring
