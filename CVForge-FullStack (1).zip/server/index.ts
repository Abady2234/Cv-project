import "dotenv/config";
import express from "express";
import cors from "cors";
import multer from "multer";
import pdfParse from "pdf-parse";
import PDFDocument from "pdfkit";
import OpenAI from "openai";

const app=express();
const port=Number(process.env.PORT||4000);
const upload=multer({storage:multer.memoryStorage(),limits:{fileSize:8*1024*1024}});
const client=new OpenAI({apiKey:process.env.OPENAI_API_KEY});
app.use(cors({origin:process.env.CLIENT_URL||"http://localhost:5173"}));
app.use(express.json({limit:"2mb"}));

const schema={
 type:"object",additionalProperties:false,required:["name","title","location","email","phone","linkedin","summary","experience","education","skills","certifications"],
 properties:{
  name:{type:"string"},title:{type:"string"},location:{type:"string"},email:{type:"string"},phone:{type:"string"},linkedin:{type:"string"},summary:{type:"string"},
  experience:{type:"array",items:{type:"object",additionalProperties:false,required:["role","company","dates","bullets"],properties:{role:{type:"string"},company:{type:"string"},dates:{type:"string"},bullets:{type:"array",items:{type:"string"}}}}},
  education:{type:"array",items:{type:"object",additionalProperties:false,required:["school","degree","dates"],properties:{school:{type:"string"},degree:{type:"string"},dates:{type:"string"}}}},
  skills:{type:"array",items:{type:"string"}},certifications:{type:"array",items:{type:"string"}}
 }
};

async function aiToCV(source:string){
 if(!process.env.OPENAI_API_KEY) throw new Error("OPENAI_API_KEY is not configured.");
 const response=await client.responses.create({
   model:process.env.OPENAI_MODEL||"gpt-5.6",
   input:[{role:"system",content:`You are a professional CV writer. Convert the supplied LinkedIn/profile text into a factual ATS-friendly CV. Never invent facts, employers, degrees, dates, metrics, skills, or achievements. You may improve grammar and turn responsibilities into stronger bullets only when supported by the source. Missing fields must be empty arrays/strings.`},{role:"user",content:source}],
   text:{format:{type:"json_schema",name:"cv",strict:true,schema}}
 });
 return JSON.parse(response.output_text);
}

function validateLinkedInUrl(url:string){
 try{const u=new URL(url);return /(^|\\.)linkedin\\.com$/i.test(u.hostname)&&/^\\/in\\/[^/]+/i.test(u.pathname)}catch{return false}
}

/*
 Direct scraping of LinkedIn profiles is intentionally NOT implemented.
 LinkedIn requires authenticated/authorized API access for member data, and
 access to richer profile fields is restricted. For a real public launch,
 use LinkedIn OAuth or the PDF export flow below.
*/
app.post("/api/generate/from-url",async(req,res)=>{
 try{
   const {url}=req.body||{};
   if(!validateLinkedInUrl(url)) return res.status(400).json({error:"Invalid LinkedIn profile URL."});
   if(!process.env.LINKEDIN_CLIENT_ID) return res.status(409).json({
     error:"LinkedIn API access is not configured. For the live product, connect LinkedIn OAuth, or upload the profile PDF exported from LinkedIn."
   });
   return res.status(409).json({
     error:"This URL requires LinkedIn authorization. Use 'Continue with LinkedIn' in the production OAuth flow, or upload your LinkedIn PDF."
   });
 }catch(e:any){res.status(500).json({error:e.message||"Server error"})}
});

app.post("/api/generate/from-pdf",upload.single("file"),async(req,res)=>{
 try{
   if(!req.file)return res.status(400).json({error:"PDF file is required."});
   if(req.file.mimetype!=="application/pdf")return res.status(400).json({error:"Only PDF files are supported."});
   const parsed=await pdfParse(req.file.buffer);
   if(!parsed.text.trim())return res.status(400).json({error:"Could not read text from this PDF."});
   const cv=await aiToCV(parsed.text.slice(0,60000));
   res.json({cv});
 }catch(e:any){console.error(e);res.status(500).json({error:e.message||"CV generation failed."})}
});

app.post("/api/cv/pdf",async(req,res)=>{
 try{
   const cv=req.body.cv; if(!cv)return res.status(400).json({error:"CV is required."});
   const doc=new PDFDocument({size:"A4",margin:48});
   res.setHeader("Content-Type","application/pdf");res.setHeader("Content-Disposition",'attachment; filename="cvforge-cv.pdf"');
   doc.pipe(res);
   doc.font("Helvetica-Bold").fontSize(22).text(cv.name||"Your Name");
   doc.font("Helvetica").fontSize(10).fillColor("#555").text(cv.title||"").text([cv.location,cv.email,cv.phone].filter(Boolean).join(" · "));
   doc.moveDown();doc.strokeColor("#dddddd").moveTo(48,doc.y).lineTo(547,doc.y).stroke();
   const section=(t:string)=>{doc.moveDown(.8);doc.fillColor("#111").font("Helvetica-Bold").fontSize(9).text(t.toUpperCase());doc.moveDown(.3)};
   section("Profile");doc.font("Helvetica").fontSize(9).fillColor("#333").text(cv.summary||"");
   if(cv.experience?.length){section("Experience");for(const e of cv.experience){doc.font("Helvetica-Bold").fontSize(10).fillColor("#111").text(e.role||"");doc.font("Helvetica").fontSize(9).fillColor("#555").text(`${e.company||""}  ${e.dates||""}`);for(const b of e.bullets||[])doc.fontSize(9).fillColor("#333").text(`• ${b}`,{indent:8});doc.moveDown(.5)}}
   if(cv.education?.length){section("Education");for(const e of cv.education){doc.font("Helvetica-Bold").fontSize(10).fillColor("#111").text(e.degree||"");doc.font("Helvetica").fontSize(9).fillColor("#555").text(`${e.school||""}  ${e.dates||""}`)}}
   if(cv.skills?.length){section("Skills");doc.font("Helvetica").fontSize(9).fillColor("#333").text(cv.skills.join(" · "))}
   if(cv.certifications?.length){section("Certifications");doc.font("Helvetica").fontSize(9).fillColor("#333").text(cv.certifications.join(" · "))}
   doc.end();
 }catch(e:any){console.error(e);res.status(500).json({error:e.message||"PDF creation failed."})}
});

app.get("/api/health",(_,res)=>res.json({ok:true,service:"cvforge"}));
app.listen(port,()=>console.log(`CVForge API running on http://localhost:${port}`));